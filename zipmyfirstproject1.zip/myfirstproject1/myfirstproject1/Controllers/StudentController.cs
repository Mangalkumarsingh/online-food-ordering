﻿using Microsoft.AspNetCore.Mvc;

namespace myfirstproject1.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
